-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2021 at 10:18 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a2zcart`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(11) NOT NULL,
  `p_type` int(11) NOT NULL,
  `p_name` varchar(400) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_image` varchar(1020) NOT NULL,
  `p_desc` longtext NOT NULL,
  `p_wstatus` tinyint(1) NOT NULL,
  `p_Cstatus` tinyint(1) NOT NULL,
  `p_quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_type`, `p_name`, `p_price`, `p_image`, `p_desc`, `p_wstatus`, `p_Cstatus`, `p_quantity`) VALUES
(1, 1, 'Canon EOS 1500D DSLR Camera Body+ 18-55 mm IS II Lens  (Black)', 45000, 'uploads/cam.png', 'his Canon Camera gives you the freedom to explore different ways to shoot subjects. It packs a multitude of shooting options which you can incorporate in still images to create art that embodies the exact mood and vision you are going for. Don’t worry abo', 0, 1, 1),
(2, 2, 'SAMSUNG Fold 2 5G (Black, 256 GB)  (12 GB RAM)', 169000, 'uploads/mob1.png', '\r\nTriple camera setup - Wide: 12MP (F1.8) + Tele: 12MP (F2.4) 2x optical zoom + UW: 12MP (F2.2) with front camera cover display (HID): 10MP (F2.2) + main display (HID): 10MP (F2.2) 19.27 centimeters (7.6-inch) dynamic AMOLED 2X - Infinity-O display, QXGA+', 0, 0, 1),
(3, 2, 'APPLE iPhone 12 Pro (Silver, 512 GB) Graiphite', 95000, 'uploads/mob2.png', '512 GB ROM -\r\n15.49 cm (6.1 inch) Super Retina XDR Display -\r\n12MP + 12MP + 12MP | 12MP Front Camera -\r\nA14 Bionic Chip with Next Generation Neural Engine Processor -\r\nCeramic Shield | IP68 Water Resistance -\r\nAll Screen OLED Display -\r\nLiDAR Scanner for Improved AR Experiences ', 0, 1, 1),
(4, 2, 'realme C12 (Power Silver, 32 GB)  (3 GB RAM)', 7999, 'uploads/mob3.png', '\r\nKeep work and entertainment going with the realme C12 smartphone featuring a 6000 mAh battery. It also comes with the Super Power Saving mode that lets you use the basic features of your phone when it is low on charge. What’s more, you can capture your surroundings well with the help of the 13 MP AI triple rear camera. You can make use of the Super Nightscape mode to click stunning pictures even in low-lit conditions.', 0, 1, 1),
(5, 2, 'SAMSUNG Galaxy F41 (Fusion Blue, 128 GB)  (6 GB RAM)', 14999, 'uploads/mob4.png', '\r\nThe Samsung Galaxy F41 is a phone you can count on for almost everything! When you have to click a picture of your family, you can fit everyone into the frame with the help of its 8 MP ultra-wide camera. Oh, and if you want to capture the beauty of your surroundings, the 64 MP camera will do the work for you! Not to forget, it is sleek and lightweight, so you can carry it around effortlessly.', 0, 0, 1),
(6, 2, 'Infinix Hot 10 Play (Morandi Green, 64 GB)  (4 GB RAM)', 8499, 'uploads/mob5.png', 'Don’t miss out on life’s precious moments by bringing home the Infinix Hot 10 Play smartphone. You can capture memories, moments, and much more on this smartphone as it comes with AI-powered 13 MP dual rear camera setup and an 8 MP selfie camera. This phone\'s large 17.3 cm (6.8) display makes it a delight to scroll through photos and watch videos. Powered by a high-capacity 6000 mAh battery, the Hot 10 Play offers long-lasting battery life to help you sail through your day.', 0, 0, 1),
(7, 3, 'ASUS ROG Strix G15 Core i5 10th Gen - (8 GB/1 TB SSD/Windows 10 Home/4 GB Graphics', 72999, 'uploads/lap1.png', 'With this ASUS Gaming Laptop, you can enjoy using it for hours, thanks to its stunning design and innovative features. It has super-narrow bezels that frame the display’s edges so that you can get an expansive view of games, movies, and more. With the NVIDIA GeForce GTX 1650 Ti GPU, you can be on top of your game as it ensures fast-paced and smooth gaming sessions. You can game for long hours while your fingers remain cool, thanks to the well-ventilated WASD keys that ensure proper airflow from the fan located below. To top it off, you will get a one-month subscription to the Xbox Game Pass on the purchase of this laptop, so you can access over 100 high-quality PC games on Windows 10 devices', 0, 0, 1),
(8, 4, 'SONY Bravia 108 cm (43 inch) Full HD LED Smart TV  (KDL-43W6603)', 37999, 'uploads/tv.png', 'The Sony Smart TV lets you sit back and enjoy various content from YouTube videos to movies, music, and more. Its screen mirroring feature enables you to cast your favourite videos, photos, or music from your smartphone to the large screen.', 0, 0, 1),
(9, 5, 'Panasonic 2 Ton 5 Star Split Inverter Smart AC with PM 2.5 Filter with Wi-fi Connect - White  (CS/CU', 53999, 'uploads/ac.png', 'The Panasonic 1.5 Ton Split Inverter AC is as elegant as it is efficient. Apart from enhancing your room’s aesthetic appeal with its sleek design, this AC also enables convenient use, courtesy of the MirAIe app. You can use the MirAIe app to instruct this AC via Google Assistant, pre-set your preferred temperature for the night, or adjust the appliance’s cooling performance from a distance with ease. Additionally, this AC’s Shield Blu feature and 100% copper coil extend its lifespan and allow it to serve you for a long time. ', 0, 0, 1),
(10, 6, 'SAMSUNG 192 L Direct Cool Single Door 3 Star Refrigerator with Base Drawer  (Saffron Blue, RR20A1Z2Y', 14890, 'uploads/rf1.png', 'The Samsung 192 L Direct Cool Refrigerator helps spruce up your dining hall while effortlessly adapting to your fashionable lifestyle. The sizeable base drawer clears up kitchen space by storing vegetables that do not require refrigeration. Equipped with a spacious Vege Box, the fridge keeps your favourite seasonal greens in one location. Moreover, its Deep Door Guard aligns multiple beverage bottles and lets you indulge in delicious, chilled refreshments on a hot summer’s day. Stylish, chic, and energy-efficient, this refrigerator can do wonders to add to the aesthetic appeal of your home.', 0, 0, 1),
(11, 7, 'gnanitha Fabric 3 Seater Sofa  (Finish Color - Multicolor, Pre-assembled)', 15500, 'uploads/sofa1.png', '    Upholestry: Cotton,\r\n    Filling Material: Foam,\r\n    W x H x D: 165 cm x 36 cm x 65 cm (5 ft 4 in x 1 ft 2 in x 2 ft 1 in),\r\n    Right Facing,\r\n    Delivery Condition: Pre Assembled (Ready to Use).', 0, 0, 1),
(12, 8, 'Online Craftbuzz Wall Decoration Intersecting Floating Shelves MDF (Medium Density Fiber) Wall Shelf', 1240, 'uploads/hmd1.png', 'BAWH Provide best Quality wall shelves That Can be used as WALL SHELVES, RACK SHELVES,WALL DECOR FOR HOME,WALL DECOR FOR HOME, WALL DECOR ITEMS, WALL DECOR FOR BEDROOM,SHELF RACK, WALL SHELVES FOR LIVING ROOM, WALL SHELVES FOR HOME DECOR,WALL SHELVES HOME DECOR FOR LIVING ROOM, WALL SHELF FOR BEDROOM, WALL SHELF FOR KITCHEN, WALL SHELF HOME DECOR WOOD,SHELVES FOR LIVING ROOM', 0, 0, 1),
(13, 9, 'Kreyam\'s Set of 15 Pattern Discs Kitchen Press', 399, 'uploads/kt1.png', 'kitchen tools set of Idiyappam maker uses for making idiyappam snacks and more other snacks of our Indian traditional snacks like a murukku , chakli, sev , bhujiya, gathiya, kitchen cookies and many more.', 0, 0, 1),
(14, 10, 'Kidz N Toys Big and Mean Rock Crawling 1:20 Scale Modified Off-Road Hummer RC Car/Monster Truck  (Mu', 1199, 'uploads/toys1.png', 'The body is extremely durable while the huge front and rear bumpers make this rc extremely rugged.', 0, 0, 1),
(15, 11, 'GTA 5 Premium Online  (Code in the Box - for PC)', 1499, 'uploads/games1.png', '    Edition: Standard Edition\r\n    Game Modes: Online Multi-Player\r\n    media_format: PC\r\n    Type: Full Game', 0, 0, 1),
(16, 12, 'Super Mario: Odyssey  (for Nintendo Switch)', 4999, 'uploads/M_G-1.png', '    Platform: Nintendo Switch\r\n    Genre: Others\r\n    Edition: Standard Edition\r\n    Game Modes: Multiplayer, Single Player', 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
