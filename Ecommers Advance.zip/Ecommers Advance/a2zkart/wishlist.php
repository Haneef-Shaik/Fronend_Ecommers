<!DOCTYPE html>
<html lang="en">
<head>
    <?php 
    include_once 'config.php';
    include_once 'head.php';

    ?>
</head>
<body>
    <?php  include_once 'header.php';  ?> 
    
    <div class="container-fluid card p-0 ">
        <div class="card-header">
            <h5 class=" d-inline-block">Wishlist</h5>
        </div>
        <?php
        $sql01="select * from products where p_wstatus=1"; 
        $res =mysqli_query($con,$sql01);
        include "card.php";
        ?>
        <div class="card-text">
        </div>
    </div>

<?php include_once "footer.php" ?>

</body>
</html>