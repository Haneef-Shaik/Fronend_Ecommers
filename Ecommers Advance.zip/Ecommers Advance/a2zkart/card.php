  <?php
  if(mysqli_num_rows($res)>0)
  {
    ?>
    <div class="container-fluid">
      <div class="row  d-flex justify-content-around align-items-center flex-wrap p-0">
        
        <?php
        while($row=mysqli_fetch_assoc($res))
        {
          $color= "orangered";
          if($row['p_wstatus']==0)
          {
            $color="lightgray";
          }
          ?>
        <div class=" position-relative card card-fst  p-0 d-flex justify-content-between align-item-center  flex-column" style="height:20rem; width:15rem ">
        <i class="fas fa-heart position-absolute likebtn" id="likebtn <?php echo 'lbtn'.$row['p_id']; ?>" data-idvalue="<?php echo $row['p_id']; ?>" style="top:2%;right:2%;font-size:1.6rem;color:<?php echo $color ?> " ></i>
            <img src="images/f2.jpg" alt="" class="card-img-top p-0 m-0" height=170 >
            <div class="card-body text-center  d-flex justify-content-around align-item-center  flex-column m-0">
              <h5 class="card-title text-dark  m-0">₹<?php echo $row['p_price'] ?></h5>
              <div class="text-module">
                <p class="" ><?php echo $row['p_name'] ?></p>
              </div>
              
              <?php 
              if($row['p_Cstatus']==1)
              {
                ?>
              <a href="mycart.php"  class="text-center text-light btn btn-danger view-btn pl-5 pr-5 mt-1 " > Go to cart</a>
              <?php 
              }
              else
              {
                ?>
              <a class="text-center text-light btn btn-danger view-btn pl-5 pr-5 mt-1 cartbtn" data-idvalue="<?php echo $row['p_id']; ?>" >Add to cart</a>
              <?php }
              ?>
            </div>
          </div>
          <?php
        }
        ?>
      </div>
    </div>
    <?php
  }
  ?>