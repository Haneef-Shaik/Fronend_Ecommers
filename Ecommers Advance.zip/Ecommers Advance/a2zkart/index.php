<!DOCTYPE html>
<html lang="en">
<head>
    <?php 
    include_once "config.php";
    include_once "head.php";
    ?>
</head>
<body>
    <?php 
        include_once "header.php";
        include_once "slider01.php";
        ?>
<!-- ------------------------------------------------- -->
<div class="container-fluid card p-0">
    <div class="card-header">
        <h5 class=" d-inline-block">Mobiles:</h5>
    </div>
    <?php
    $sql01="select * from products where p_type=2"; 
    $res =mysqli_query($con,$sql01);
    include "card.php";
    ?>
    <div class="card-text">
    </div>
    <div class="card-footer">
        <button class="btn float-right view-btn">View All</button>
    </div>
</div>
    <!-- --------------------------------------------- -->



    <div class="container-fluid card p-0">
    <div class="card-header">
        <h5 class=" d-inline-block">Top Grossing</h5>
    </div>
    <?php
    $sql01="select * from products where p_type in ( 1,3,4,5,6)"; 
    $res =mysqli_query($con,$sql01);
    include "card.php";
    ?>
    <div class="card-text">
    </div>
    <div class="card-footer">
        <button class="btn float-right view-btn">View All</button>
    </div>
</div>
<!-- --------------------------------- -->
<?php include_once "footer.php" ?>
</body>
</html>