<?php 

$con = mysqli_connect('localhost','root','','mycart') or die("!! Unable to connect to database !!") ?> 