<!DOCTYPE html>
<html lang="en">
<head>
    <?php 
    include_once 'config.php';
    include_once 'head.php';

    ?>
</head>
<body>
    <?php  include_once 'header.php';  ?> 

    <div class="container-fluid card p-0">
    <div class="card-header">
        <h5 class=" d-inline-block">My Cart</h5>
    </div>
    <?php
    $sql01="select * from products where p_Cstatus=1 "; 
    $res =mysqli_query($con,$sql01);
    ?>

<?php
  if(mysqli_num_rows($res)>0)
  {
    ?>
    <div class="container-fluid">
      <div class="row  d-flex justify-content-around align-items-center flex-wrap p-0">
        
        <?php
        while($row=mysqli_fetch_assoc($res))
        {
          $color= "orangered";
          if($row['p_wstatus']==0)
          {
            $color="lightgray";
          }
          ?>
        <div class=" position-relative card card-fst  p-0 d-flex justify-content-between align-item-center  flex-column" style="height:20rem; width:15rem ">
        <i class="fas fa-heart position-absolute likebtn" id="likebtn <?php echo 'lbtn'.$row['p_id']; ?>" data-idvalue="<?php echo $row['p_id']; ?>" style="top:2%;right:2%;font-size:1.6rem;color:<?php echo $color ?> " ></i>
            <img src="images/f2.jpg" alt="" class="card-img-top p-0 m-0" height=170 >
            <div class="card-body text-center  d-flex justify-content-around align-item-center  flex-column m-0">
              <h5 class="card-title text-dark  m-0">₹<?php echo $row['p_price'] ?></h5>
              <div class="text-module">
                <p class="" ><?php echo $row['p_name'] ?></p>
              </div>
              <a href="mycart.php"  class="text-center text-light btn btn-danger view-btn pl-5 pr-5 mt-1 rmvbtn" data-idvalue="<?php echo $row['p_id']; ?>" >remove</a>
            </div>
          </div>
          <?php
        }
        ?>
      </div>
    </div>
    <div class="card-footer">
        <button class="btn float-right view-btn">Checkout</button>
    </div>
    <?php
  }
  else{
  ?>
    <h1 class="text-center ">No items Selected <br> <a href="index.php" class="text-center" style="text-decoration: none;font-size:5vw;font-family:'Times New Roman', Times, serif ">Shop Now</a> </h1>
  <?php
  }
  ?>
    
</div>






<?php include_once "footer.php" ?>

</body>
</html>