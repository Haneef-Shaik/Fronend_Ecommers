<!--------------------- Ajax -------------------------------->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
        $('.likebtn').on("click",function(e){
            var value = $(this).data('idvalue');
            var col="p_wstatus";
            $.ajax({
                url:'ajax01.php',
                type:'POST',
                data:{'id':value, 'col' : col },
                success:function(data)
                {
                    location.reload();
                }
            });
        });


        $('.cartbtn').on("click",function(e){
            var value = $(this).data('idvalue');
            var col="p_Cstatus";
            $.ajax({
                url:'ajax01.php',
                type:'POST',
                data:{'id':value, 'col' : col },
                success:function(data)
                {
                    location.reload();
                }
            });
        });


        $('.rmvbtn').on("click",function(e){
            var value = $(this).data('idvalue');
            var col="p_Cstatus";
            $.ajax({
                url:'ajax02.php',
                type:'POST',
                data:{'id':value, 'col' : col },
                success:function(data)
                {
                    location.reload();
                }
            });


        });
    });
</script>

<!-------------------Java Script----------------------------->
<script>

  const loginForm = document.querySelector("form.login");
  const signupForm = document.querySelector("form.signup");
  const loginBtn = document.querySelector("label.login");
  const signupBtn = document.querySelector("label.signup");
  const signupLink = document.querySelector(".signup-link a");
  const loginLink = document.querySelector(".login-link");
  const stab=document.querySelector(".slide-tab");

  signupBtn.onclick=(()=>{
      loginForm.style.marginLeft="-50%";
      stab.style.left="50%";
      loginBtn.style.color="black";
      signupBtn.style.color="white";
      
    });
    
    loginBtn.onclick=(()=>{
      loginForm.style.marginLeft="0%";
      stab.style.left="0%";
      signupBtn.style.color="black";
      loginBtn.style.color="white";
      

  });

  signupLink.onclick=(()=>{
      signupBtn.click();
      return false;
  });

  loginLink.onclick=(()=>{
      loginBtn.click();
      return false;
  });
</script>
<!-- ---------------------- -->

<script>
    $('.catbtn').click(function(){
        $('#cattypes').toggleClass("d-none");
    });
</script>
<!-- ----------------- -->


<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>