<?php 
    $id = $_POST['id'];
    $col = $_POST['col'];

    include "config.php";
    $sql="select * from products where p_id={$id} ";
    $res=mysqli_query($con,$sql);
    if(mysqli_num_rows($res)>0)
    {
        while($row=mysqli_fetch_assoc($res))
        {
            if($row[$col]==1)
            $sql1="update products set {$col}=0 where p_id={$id} ";
            else
            $sql1="update products set {$col}=1 where p_id={$id} ";

            mysqli_query($con,$sql1);

            echo "done";

        }
    }

?>