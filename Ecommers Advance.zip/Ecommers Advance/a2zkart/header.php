<div class="container-fluid">
        <div class="row">
            <div class="col-12 p-0">
            <nav class="navbar navbar-expand-lg navbar-dark bg-danger p-0">
                <a class="navbar-brand" href="index.html"><img src="images/logoc_2.png" alt="" height="45vh"> <span style="font-family: 'Sansita Swashed', cursive;"> A2ZKart </span></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
            
                <div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
                    <form class="form-inline  ml-auto text-center d-inline-flex justify-content-center" >
                        <input class="form-control" type="text" placeholder="Search Electric , Tv's ,Mobiles...," aria-label="Search" style="min-width:350px;border: none;outline: none; border-left:5px solid rgb(0, 0, 0);" >
                        <button class="btn btn-outline-light ml-1 p-1" type="submit">Search</button>
                    </form>
                    <ul class="navbar-nav ml-auto text-center d-md-flex justify-content-between align-items-center" style="min-width: 200px;">
                        <li class="nav-item  active">
                        <a class="nav-link mr-1" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>

                        <li class="nav-item dropdown menu-area">
                  <a class="nav-link dropdown-toggle" href="#" id="mega-two" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;font-weight:600;font-family:'Times New Roman', Times, serif;font-size:larger;text-shadow:none;">
                    Categories
                  </a>
                  <div class="dropdown-menu mega-area container-fluid text-center text-light" aria-labelledby="mega-two" style="background: radial-gradient(red,black);">
                    <div class="row">
                      <div class="col-sm-6 col-lg-3">
                        <h5>Electronics</h5>
                        <a href="cat.php?value=1" class="dropdown-item text-light bg-transparent">cameras</a>
                        <a href="cat.php?value=2" class="dropdown-item text-light bg-transparent">Mobiles</a>
                        <a href="cat.php?value=3" class="dropdown-item text-light bg-transparent">Laptops</a>
                        <a href="cat.php?value=4" class="dropdown-item text-light bg-transparent">TVs</a>
                        <a href="cat.php?value=5" class="dropdown-item text-light bg-transparent">A.C</a>
                        <a href="cat.php?value=6" class="dropdown-item text-light bg-transparent">Refrigerator</a>
                      </div>
                      <div class="col-sm-6 col-lg-3">
                        <h5>Home</h5>
                        <a href="cat.php?value=7" class="dropdown-item text-light bg-transparent">Sofa</a>
                        <a href="cat.php?value=8" class="dropdown-item text-light bg-transparent">Home Decorators</a>
                        <a href="cat.php?value=9" class="dropdown-item text-light bg-transparent">Kitchen</a>
                      </div>
                      <div class="col-sm-6 col-lg-3">
                        <h5>Toys</h5>
                        <a href="cat.php?value=10" class="dropdown-item text-light bg-transparent">toys</a>
                        <a href="cat.php?value=11" class="dropdown-item text-light bg-transparent">Games</a>
                        <a href="cat.php?value=12" class="dropdown-item text-light bg-transparent">Multiplayer Games</a>
                      </div>
                    </div>
                  </div>
                </li>
                        <li class="nav-item  ">
                        <a class="nav-link mr-1" href="wishlist.php"  style="color: white;font-weight:600;font-family:'Times New Roman', Times, serif;"><i class="fas fa-heart"></i></a>
                        </li>

                        <li class="nav-item  ">
                        <a class="nav-link mr-1" href="mycart.php"  style="color: white;font-weight:600;font-family:'Times New Roman', Times, serif;"><i class="fas fa-shopping-cart"></i></a>
                        </li>

                        <li class="nav-item">
                            <a class="btn nav-link" data-toggle="modal" data-target="#exampleModal"
                                style="color: white;font-weight:600;font-family:'Times New Roman', Times, serif;"> Sign
                                in </a>
                                
                        </li>
                    </ul>
                </div>
                </nav>
            </div>
        </div>
</div>


<!-- --------------------------------------------------------------------------------------------- -->

    <!-- Button trigger modal -->
    

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
        <div class="modal-dialog" role="document">
            <div class="modal-content wrapper">
    
                    <button type="button" class="close d-block ml-auto" data-dismiss="modal" aria-label="Close" style="width:5%;">
                        <span aria-hidden="true" style="color:orangered">&times;</span>
                    </button>
    
                <div class="modal-body">
                    <div class="form-container">
                        <div class="slide-controls">
                            <input type="radio" name="slider" id="login"  value="Login"  checked>
                            <input type="radio" name="slider" id="signup" value="Login" >
                            
                            <label for="login" class="slide p-0 login " style="color:white;">Login</label>
                            <label for="signup" class="slide p-0 signup" >Signup</label>
                            
                            
                            <div class="slide-tab"></div>
                        </div>
                        <div class="form-inner">
                            <form action="#" class="login">
                                <div class="field">
                                    <input type="text" placeholder="Email Address"  required>
                                </div>
                                <div class="field">
                                    <input type="password" placeholder="Password" required>
                                </div>
                                <div class="pass-link">
                                    <a href="#">Forget password?</a>
                                </div>
                                <div class="field">
                                    <input class="bg-danger" type="submit" value="Login">
                                </div>
                                <div class="signup-link">Not a member? <a href="#">Signup now</a></div>
                            </form>
    <!-- ----------------------------- -->
                            <form action="#" class="Signup">
                                <div class="field">
                                    <input type="text" placeholder="Email Address"  required>
                                </div>
                                <div class="field">
                                    <input type="password" placeholder="Password" required>
                                </div>
                                <div class="field">
                                    <input type="password" placeholder="Confirm Password" required>
                                </div>
                                <div class="field">
                                    <input class="bg-danger" type="submit" value="Signup">
                                </div>
                                <div class="login-link">Already a member? <a href="#">login now</a></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-------------------------------------------------------------------------------------------------------------------------------------->

