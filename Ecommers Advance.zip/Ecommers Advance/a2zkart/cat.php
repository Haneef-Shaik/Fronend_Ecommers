<!DOCTYPE html>
<html lang="en">
<head>
    <?php 
    include_once 'config.php';
    include_once 'head.php';

    ?>
</head>
<body>
    <?php  include_once 'header.php';
    $sql01="select * from products where p_type={$_GET['value']}"; 
    $res =mysqli_query($con,$sql01);
    ?> 
    
    <div class="container-fluid card p-0 ">
        <div class="card-header">
        </div>
        <?php
        
        include "card.php";
        ?>
        <div class="card-text">
        </div>
    </div>

<?php include_once "footer.php" ?>

</body>
</html>